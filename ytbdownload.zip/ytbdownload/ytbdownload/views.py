"""Processing logic of Youtube downbload project."""
import datetime
import json
from wsgiref.util import FileWrapper
from django.http import HttpResponse
from django.shortcuts import render
from pytube import YouTube
from .utils import cleanup, findres, findtag
from .settings import BASE_DIR


tag_dict={}
def index(request):
    """This function is to load the homepage, perform cleanup of old mp4 files and return video details"""
    if request.method=="POST" and 'Submiturl' in request.POST:
        link=request.POST.get('urllink','')
        link=repr(link)
        video=YouTube(link)
        title=video.title
        duration=video.length
        duration=str(datetime.timedelta(seconds = duration))
        views=video.views
        filter_vid=video.streams.filter(progressive="True")
        filter_vid=str(filter_vid)
        listgen = filter_vid.split("Stream:")
        global tag_dict
        for data in listgen[1:]:
            res=findres(data)
            tag=findtag(data)
            tag_dict[tag]=res
        param={'link':link,'title':title,'duration':duration,'views':views,'dict':tag_dict}
        return HttpResponse(json.dumps(param))
    cleanup(BASE_DIR)     #Cleaning old media files.
    return render(request,'home.html')

def download(request):
    """This function downloads video locally and return the video."""
    url = request.POST.get('videourl', '')
    path = request.POST.get('Downloadpath', '')
    res = request.POST.get('selectreso', '')
    key_list = list(tag_dict.keys())
    val_list = list(tag_dict.values())
    itag = key_list[val_list.index(res)]
    video = YouTube(url)
    val = video.streams.get_by_itag(itag).download(path)
    file = FileWrapper(open(val, 'rb'))
    response = HttpResponse(file, content_type='video/mp4')
    response['Content-Disposition'] = 'attachment; filename=my_video.mp4'
    file.close()
    return response

def contact(request):
    """Future development"""
    return render(request,'aboutus.html')
