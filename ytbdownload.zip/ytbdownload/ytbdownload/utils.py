"""Utils file for python functions"""
import os

def cleanup(directory):
    print("Cleaning--", directory)
    all_files = os.listdir(directory)
    print(all_files)
    # filtered_files = [file for file in all_files if file.endswith(".mp4")]
    ext = (".mp4", ".3gpp")
    filtered_files = [file for file in all_files if file.endswith(ext)]
    for file in filtered_files:
        path_to_file = os.path.join(directory, file)
        os.remove(path_to_file)
        print("Removed -", path_to_file)

def findres(data):
    val = data.find("res=")
    val2 = data[val + 5:]
    val2 = val2.find('"')
    res = data[val + 5:val + 5 + val2]
    return res

def findtag(data):
    val = data.find("itag=")
    val2 = data[val + 6:]
    val2 = val2.find('"')
    res = data[val + 6:val + 6 + val2]
    return res